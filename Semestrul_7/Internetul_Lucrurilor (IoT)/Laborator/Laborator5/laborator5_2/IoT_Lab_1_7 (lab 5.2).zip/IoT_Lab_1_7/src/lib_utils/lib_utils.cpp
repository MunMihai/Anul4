#include "lib_utils.h"
#include "stdint.h"

//----------------------------------------------------------------
// Delay function based on CPU frequency
// it does not use any timer or OS delay function
// it is just a busy wait loop
// evaluated on nr of instructions per second on CPU frequency
volatile int my_delay_cnt = 0;
#define LOOP_INSTRUCTION_SIZE 16
#define L00P_SEC 1000L
#define LOOP_CNT ((F_CPU / L00P_SEC) / (LOOP_INSTRUCTION_SIZE))
void my_delay(long delay_ms)
{
    // set compiler to not optimize this section
    for (int64_t i = 0; i < delay_ms; i++)
    {
        for (int64_t j = 0; j < LOOP_CNT; j++)
        {
            // do nothing
            my_delay_cnt++;
        }
    }
}
