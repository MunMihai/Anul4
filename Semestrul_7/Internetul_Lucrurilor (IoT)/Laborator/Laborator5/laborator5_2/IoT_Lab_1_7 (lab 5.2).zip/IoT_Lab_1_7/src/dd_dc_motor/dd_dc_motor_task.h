#ifndef DD_DC_MOTOR_TASK_H
#define DD_DC_MOTOR_TASK_H

// Include standard libraries
#include "Arduino_FreeRTOS.h"

// Include the project libraries
#include "dd_dc_motor.h"

// Define any constants
#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif
#ifndef DD_DC_MOTOR_TASK_REC
#define DD_DC_MOTOR_TASK_REC (10/SYS_TICK)
#endif
#ifndef DD_DC_MOTOR_TASK_OFFSET
#define DD_DC_MOTOR_TASK_OFFSET (100/SYS_TICK)
#endif

// Declare any global variables

// Declare any function prototypes

void dd_dc_motor_task_freertos(void *pvParameters);

#endif // DD_DC_MOTOR_TASK_H