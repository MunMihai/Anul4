#include "ed_dht_task.h"
#include "ed_dht.h"
#include "Arduino_FreeRTOS.h"

// FreeRTOS task adaptation of the reccuring temperature sensor task
void ed_dht_task_freertos(void *pvParameters)
{
    // Initialize the temperature sensor component
    ed_dht_setup();
    vTaskDelay(ED_DHT_TASK_OFFSET);

    while (1)
    {

        // Run the temperature sensor recurring loop
        ed_dht_loop();

        // Delay for the temperature sensor task recurrence
        vTaskDelay(ED_DHT_TASK_REC);
    }
}