#include "app_lab_2_1.h"
#include "srv_heartbeat/srv_heartbeat.h"
#include "srv_serial_stdio/srv_serial_stdio.h"
#include "Arduino.h"


#define SYS_TICK 1

#define SRV_HEARTBEAT_TASK_REC (500/SYS_TICK)
#define SRV_HEARTBEAT_TASK_OFFSET (10000/SYS_TICK)
int srv_heartbeat_task_counter = SRV_HEARTBEAT_TASK_OFFSET;


#define DUMMY_TASK_REC (1000/SYS_TICK)
#define DUMMY_TASK_OFFSET (20000/SYS_TICK)
int dummy_task_counter = DUMMY_TASK_OFFSET;


// setup Timer1 to 1 ms interrupt recurecy

// setup system timer0 on 1 ms
void srv_sys_os_timer_setup()
{
    // Set up the system timer to generate an interrupt every 1 ms
    // Set the CTC mode
    TCCR1B |= (1 << WGM12);
    // Set the compare match register to 1ms
    OCR1A = 16000;
    // Enable the compare match interrupt
    TIMSK1 |= (1 << OCIE1A);
    // Set the prescaler to 64 and start the timer
    TCCR1B |= (1 << CS11) | (1 << CS10);
}


void dummy_task_setup(){

}

void dummy_task_loop(){
 printf("Dummy Task\n");
}



void srv_sys_os_time_scheduler()
{
    // This function is called every 1 ms
    // It should be used to implement a time scheduler

    if (--srv_heartbeat_task_counter <= 0)
    {
        srv_heartbeat_task_counter = SRV_HEARTBEAT_TASK_REC;
        srv_heartbeat_loop();
    }
    
    if(--dummy_task_counter <= 0)
    {
        dummy_task_loop();
        dummy_task_counter = DUMMY_TASK_REC;
    }

}

ISR(TIMER1_COMPA_vect)
{
    // Call the scheduler
    srv_sys_os_time_scheduler();
}


void app_lab_2_1_setup()
{
    // Set up the application
	
     // Set up the system timer
    srv_sys_os_timer_setup();
	
	// Set up the serial driver
    srv_serial_setup();

    // Set up the heartbeat
    srv_heartbeat_setup();
    srv_heartbeat_task_counter = SRV_HEARTBEAT_TASK_OFFSET;

    dummy_task_setup();
    dummy_task_counter = DUMMY_TASK_OFFSET;

    printf("App Lab 2.1 setup Done\n");

}

void app_lab_2_1_loop()
{
    // srv_sys_os_time_scheduler();
    delay(1000*SYS_TICK);// do nothig

    printf("App Lab 2.1 Idle process\n");

}