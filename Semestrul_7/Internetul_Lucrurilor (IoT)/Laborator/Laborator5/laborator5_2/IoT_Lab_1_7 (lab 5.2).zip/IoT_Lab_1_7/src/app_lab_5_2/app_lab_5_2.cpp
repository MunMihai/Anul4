#include "app_lab_5_2.h"

#include "srv_heartbeat/srv_heartbeat_task.h"
#include "srv_serial_stdio/srv_serial_stdio.h"
#include "dd_dc_motor/dd_dc_motor_task.h"
#include "dd_sns_angle/dd_sns_angle_task.h"

#include "Arduino_FreeRTOS.h"

#include "Arduino.h"

#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif

#ifndef APP_LAB_5_2_TASK_REC
#define APP_LAB_5_2_TASK_REC (10 / SYS_TICK)
#endif

#ifndef APP_LAB_5_2_TASK_OFFSET
#define APP_LAB_5_2_TASK_OFFSET (1000 / SYS_TICK)
#endif

float CTRL_K_P = 1.0;
float CTRL_K_D = 0.01;
float CTRL_K_I = 0.09;

int ctrl_pid_out_p = 0;
int ctrl_pid_out_d = 0;
int ctrl_pid_out_i = 0;

int ctrl_pid_out = 0;

int ctrl_pid_error = 0;
int ctrl_pid_error_prev = 0;
#define CTRL_PID_ERROR_BUFFER_SIZE 20
int ctrl_pid_error_buffer[CTRL_PID_ERROR_BUFFER_SIZE];
int ctrl_pid_error_buffer_index = 0;
int ctrl_pid_error_sum = 0;

int ctrl_pid_desired_value = 90;
int ctrl_pid_current_value = 0;

void app_lab_5_2_task_freertos(void *pvParameters)
{

    printf("App Lab 5.2 Task Initiated\n");

    vTaskDelay(APP_LAB_5_2_TASK_OFFSET);
    printf("App Lab 5.2 Task Started\n");

    while (1)
    {
        // printf("App Lab 5.2 Task Run\n");

        ctrl_pid_current_value = dd_sns_angle_get_phy_value();
        // print current positin
        // printf("Current Position: %d\n", ctrl_pid_current_value);

        if (Serial.available() > 0)
        {
            ctrl_pid_desired_value = Serial.parseInt();
            // printf("Desired Position Updated: %d\n", ctrl_pid_desired_value);
        }

        // print desired position
        // printf("Desired Position: %d\n", ctrl_pid_desired_value);

        // 0. Evaluate the position error
        ctrl_pid_error_prev = ctrl_pid_error;
        ctrl_pid_error = ctrl_pid_desired_value - ctrl_pid_current_value;
        // print position error
        // printf("Position Error: %d\n", ctrl_pid_error);
        // printf("Position Error Previous: %d\n", ctrl_pid_error_prev);

        // 1. Proportional Control
        ctrl_pid_out_p = CTRL_K_P * ctrl_pid_error;
        // print control output
        // printf("Control Output: %d\n", ctrl_pid_out_p);

        // 2. Differential Control
        ctrl_pid_out_d = CTRL_K_D * (ctrl_pid_error - ctrl_pid_error_prev);
        // print control output
        // printf("Differential Control Output: %d\n", ctrl_pid_out_d);

        // 3. Integral Control
        ctrl_pid_error_buffer[ctrl_pid_error_buffer_index] = ctrl_pid_error;
        ctrl_pid_error_buffer_index++;
        ctrl_pid_error_buffer_index %= CTRL_PID_ERROR_BUFFER_SIZE;

        ctrl_pid_error_sum = 0;
        for (int i = 0; i < CTRL_PID_ERROR_BUFFER_SIZE; i++)
        {
            ctrl_pid_error_sum += ctrl_pid_error_buffer[i];
        }

        ctrl_pid_out_i = CTRL_K_I * ctrl_pid_error_sum;

        // print control output
        // printf("Integral Control Output: %d\n", ctrl_pid_out_i);

        // evaluate the control output
        ctrl_pid_out = ctrl_pid_out_p + ctrl_pid_out_d + ctrl_pid_out_i;

        // print control output
        // printf("PID Control Output: %d\n", ctrl_pid_out);

        int motor_pow = dd_dc_motor_set_power(ctrl_pid_out);
        // printf("Motor Power: %d\n", motor_pow);

        // Arduino terminal Plotter
        printf("Vd:%d, Vc:%d, Err:%d, P:%d, D:%d, I:%d, PID:%d, Pwr:%d\n\r",
               ctrl_pid_desired_value,
               ctrl_pid_current_value,
               ctrl_pid_error,
               ctrl_pid_out_p,
               ctrl_pid_out_d,
               ctrl_pid_out_i,
               ctrl_pid_out,
               motor_pow);

        vTaskDelay(APP_LAB_5_2_TASK_REC);
    }
}

void app_lab_5_2_setup()
{
    // Set up the serial service
    srv_serial_setup();
    printf("App Lab 5.2 Setup\n");
    // Start up the heartbeat service
    xTaskCreate(srv_heartbeat_task_freertos, "Heartbeat", 1024, NULL, 1, NULL);
    // Start up the motor driver
    xTaskCreate(dd_dc_motor_task_freertos, "DC Motor", 1024, NULL, 1, NULL);
    // Start up the angle sensor
    xTaskCreate(dd_sns_angle_task_freertos, "Angle Sensor", 2024, NULL, 1, NULL);
    // Start up the app lab 5.2 task
    xTaskCreate(app_lab_5_2_task_freertos, "App Lab 5.2", 2024, NULL, 1, NULL);

    // Start the scheduler
    vTaskStartScheduler();
}

void app_lab_5_2_loop()
{
    // Idle loop
}
