#ifndef DD_FAN_TASK_H
#define DD_FAN_TASK_H

// Include standard libraries
#include <Arduino_FreeRTOS.h>

// Include the project libraries
#include "dd_fan.h"

// Define any constants
#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif
#ifndef DD_FAN_TASK_REC
#define DD_FAN_TASK_REC (10/SYS_TICK)
#endif
#ifndef DD_FAN_TASK_OFFSET
#define DD_FAN_TASK_OFFSET (100/SYS_TICK)
#endif

// Declare any global variables

// Declare any function prototypes

void dd_fan_task_freertos(void *pvParameters);

#endif // DD_FAN_TASK_H