#ifndef APP_LAB_0_H
#define APP_LAB_0_H

// Include any necessary libraries here

// Define any constants or global variables here

// Declare function prototypes here
void app_lab_0_setup();
void app_lab_0_loop();

#endif // APP_LAB_0_H