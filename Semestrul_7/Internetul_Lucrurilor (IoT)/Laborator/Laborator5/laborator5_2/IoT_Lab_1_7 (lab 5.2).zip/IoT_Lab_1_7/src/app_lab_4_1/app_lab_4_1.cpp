#include "app_lab_4_1.h"

#include "srv_heartbeat/srv_heartbeat_task.h"
#include "srv_serial_stdio/srv_serial_stdio.h"
#include "ed_relay/ed_relay_task.h"
#include "dd_fan/dd_fan_task.h"
#include "Arduino_FreeRTOS.h"
#include "Arduino.h"

#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif
#ifndef APP_LAB_4_1_TASK_REC
#define APP_LAB_4_1_TASK_REC (500 / SYS_TICK)
#endif
#ifndef APP_LAB_4_1_TASK_OFFSET
#define APP_LAB_4_1_TASK_OFFSET (1000 / SYS_TICK)
#endif



void app_lab_4_1_task_freertos(void *pvParameters)
{

    printf("App Lab 4.1 Task Initiated\n");

    vTaskDelay(APP_LAB_4_1_TASK_OFFSET);
    printf("App Lab 4.1 Task Started\n");

    while (1)
    {   

        printf("App Lab 4.1 Task Run\n");


        if(Serial.available()){
            char c = Serial.read();
            if(c == '1'){
                dd_fan_on();
            }
            if(c == '0'){
                dd_fan_off();
            }
        }

        // Print report of realy state
        ed_relay_report();
        dd_fan_report();

        vTaskDelay(APP_LAB_4_1_TASK_REC);
    }
}


void app_lab_4_1_setup()
{
    // Set up the serial service
    srv_serial_setup();
    printf("App Lab 4.1 Setup\n");
    // Start up the heartbeat service
    xTaskCreate(srv_heartbeat_task_freertos, "Heartbeat", 1024, NULL, 1, NULL);
    // Start up the relay driver
    xTaskCreate(ed_relay_task_freertos, "Relay", 1024, NULL, 1, NULL);
    // Start up the fan driver
    xTaskCreate(dd_fan_task_freertos, "Fan", 1024, NULL, 1, NULL);



    // start app_lab_4_1_task_freertos
    xTaskCreate(app_lab_4_1_task_freertos, "AppLab4.1", 1024, NULL, 1, NULL);

    // Start the FreeRTOS scheduler
    vTaskStartScheduler();

}

void app_lab_4_1_loop()
{
    // Idle task in main loop
}