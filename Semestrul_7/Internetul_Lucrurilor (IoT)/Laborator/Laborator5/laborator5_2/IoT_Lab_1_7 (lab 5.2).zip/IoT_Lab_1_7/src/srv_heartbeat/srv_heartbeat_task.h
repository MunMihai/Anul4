#ifndef SRV_HEARTBEAT_TASK_H
#define SRV_HEARTBEAT_TASK_H

// Include standard libraries

// Include the project libraries

// Define any constants

#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif

#ifndef SRV_HEARTBEAT_TASK_REC
#define SRV_HEARTBEAT_TASK_REC (500/SYS_TICK)
#endif

#ifndef SRV_HEARTBEAT_TASK_OFFSET
#define SRV_HEARTBEAT_TASK_OFFSET (10000/SYS_TICK)
#endif

// Declare any global variables

// Declare any function prototypes

void srv_heartbeat_task_freertos(void *pvParameters);

#endif // SRV_HEARTBEAT_TASK_H