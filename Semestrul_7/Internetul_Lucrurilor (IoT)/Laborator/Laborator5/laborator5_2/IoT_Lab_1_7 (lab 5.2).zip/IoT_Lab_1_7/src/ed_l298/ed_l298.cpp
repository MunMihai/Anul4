#include "ed_l298.h"

#include "Arduino.h"

int ed_l298_pin_map[ED_L298_CHANNEL_NR_OF] = {3, 4};
int ed_l298_power[ED_L298_CHANNEL_NR_OF] = {0, 0};
int ed_ld98_ENA_pin = 2;
int ed_ld98_ENA_state = 0;

int ed_l298_set_power(int channel, int power)
{
    if (power > 100)
    {
        power = 100;
    }
    if (power < 0)
    {
        power = 0;
    }
    ed_l298_power[channel] = power;
    return ed_l298_power[channel];
}

int ed_l298_set_hw_power(int channel, int power)
{
    if (power > 255)
    {
        power = 255;
    }
    if (power < 0)
    {
        power = 0;
    }
    ed_l298_power[channel] = power;
    analogWrite(ed_l298_pin_map[channel], power);
    return ed_l298_power[channel];
}

int ed_l298_ENA_on()
{
    ed_ld98_ENA_state = 1;
    digitalWrite(ed_ld98_ENA_pin, HIGH);
    return ed_ld98_ENA_state;
}
int ed_l298_ENA_off()
{
    ed_ld98_ENA_state = 0;
    digitalWrite(ed_ld98_ENA_pin, LOW);
    return ed_ld98_ENA_state;
}

void ed_l298_setup()
{
    // Set up the L298
    for(int i = 0; i < ED_L298_CHANNEL_NR_OF; i++){
        pinMode(ed_l298_pin_map[i], OUTPUT);
    }
    for (int i = 0; i < ED_L298_CHANNEL_NR_OF; i++)
    {
        ed_l298_set_power(i, 0);
    }
    ed_l298_ENA_on();

}

void ed_l298_loop()
{
    // Run the L298 loop
    for(int i = 0; i < ED_L298_CHANNEL_NR_OF; i++){
        ed_l298_set_hw_power(i, ed_l298_power[i]);
    }
}