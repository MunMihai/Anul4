#ifndef ED_L298_H
#define ED_L298_H

// Include standard libraries

// Include the project libraries

// Define any constants
enum ED_L298_CHANNEL
{
    ED_L298_CHANNEL_1,
    ED_L298_CHANNEL_2,
    ED_L298_CHANNEL_NR_OF
};


// Declare any global variables

// Declare any function prototypes
void ed_l298_setup();
void ed_l298_loop();
int ed_l298_set_power(int channel, int power);
int ed_l298_set_hw_power(int channel, int power);
int ed_l298_ENA_on();
int ed_l298_ENA_off();

#endif // ED_L298_H