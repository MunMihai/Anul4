#ifndef APP_LAB_3_1_H
#define APP_LAB_3_1_H


// Include standard libraries


// Define any constants


// Declare any global variables


// Declare any function prototypes

void app_lab_3_1_setup();
void app_lab_3_1_loop();


#endif // APP_LAB_3_1_H