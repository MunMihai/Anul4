#include "app_lab_2_2.h"

#include "srv_heartbeat/srv_heartbeat_task.h"
#include "srv_serial_stdio/srv_serial_stdio.h"
#include "lib_utils/lib_utils.h"
#include <Arduino_FreeRTOS.h>


#define DUMMY_TASK_REC (1000 / SYS_TICK)
#define DUMMY_TASK_OFFSET (5000 / SYS_TICK)

//----------------------------------------------------------------
// dummy task component initialization
void dummy_task_setup_2()
{
    // Enter critical section
    // As we are using printf inside the function
    // we need to protect the critical section
    taskENTER_CRITICAL();

    // print a debug message from initialization
    printf("Dummy Task Started\n");
    // Exit critical section
    taskEXIT_CRITICAL();
}

//----------------------------------------------------------------
// dummy task component loop
void dummy_task_loop_2()
{
    // Enter critical section
    // As we are using printf inside the function
    // we need to protect the critical section
    taskENTER_CRITICAL();

    // print a debug message from the loop
    printf("Dummy Task run\n");

    // Exit critical section
    taskEXIT_CRITICAL();
}

//----------------------------------------------------------------
// a freertos adaption of a recurring task
void dummy_task_freertos(void *pvParameters)
{
    // dummy task component initialization
    dummy_task_setup_2();
    // delay for task offset
    vTaskDelay(DUMMY_TASK_OFFSET);

    while (1)
    {
        // Enter critical section
        // As we are using printf inside the function
        // we need to protect the critical section
        taskENTER_CRITICAL();

        // dummy task recurring loop
        dummy_task_loop_2();

        // Exit critical section
        taskEXIT_CRITICAL();

        // delay for task run recurrence
        vTaskDelay(DUMMY_TASK_REC);
    }
}


//----------------------------------------------------------------
// The setup function for the application
void app_lab_2_2_setup()
{

    // Set up the serial service
    srv_serial_setup();

    // create a task for heartbeat
    xTaskCreate(
        srv_heartbeat_task_freertos, // Function that should be called
        "Heartbeat",                 // Name of the task (for debugging)
        1000,                        // Stack size (words)
        NULL,                        // Parameter to pass
        1,                           // Task priority
        NULL                         // Task handle
    );

    xTaskCreate(dummy_task_freertos, "DummyTask", 2000, NULL, 1, NULL);

    // Start the FreeRTOS scheduler
    vTaskStartScheduler();
}

//----------------------------------------------------------------
// The idle process for the application
void app_lab_2_2_loop()
{
    my_delay(1000); // do nothing

    // // Enter critical section
    taskENTER_CRITICAL();
    // // As we are using printf
    // we need to protect the critical section

    // Print a debug message from the idle process
    printf("App Lab 2.2 Idle process\n");

    // Serial.println("App Lab 2.2 Idle process");
    // // Exit critical section
    taskEXIT_CRITICAL();
}