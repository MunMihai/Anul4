#ifndef ED_DHT_TASK_H
#define ED_DHT_TASK_H


// Include standard libraries


// Include the project libraries
#include "ed_dht.h"

// Define any constants
#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif
#ifndef ED_DHT_TASK_REC
#define ED_DHT_TASK_REC (100/SYS_TICK)
#endif
#ifndef ED_DHT_TASK_OFFSET
#define ED_DHT_TASK_OFFSET (100/SYS_TICK)
#endif

// Declare any global variables


// Declare any function prototypes

void ed_dht_task_freertos(void *pvParameters);

#endif // ED_DHT_TASK_H