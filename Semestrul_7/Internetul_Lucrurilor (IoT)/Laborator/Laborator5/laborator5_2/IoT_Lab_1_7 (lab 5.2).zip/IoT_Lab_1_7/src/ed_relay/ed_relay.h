#ifndef ED_RELAY_H
#define ED_RELAY_H

// Include standard libraries

// Include the project libraries

// Define any constants
#define ED_RELAY_PIN 2

#define ED_RELAY_ON 1
#define ED_RELAY_OFF 0

// Declare any global variables

// Declare any function prototypes

void ed_relay_setup();
void ed_relay_loop();

int ed_relay_on();
int ed_relay_off();
int ed_relay_hw_on();
int ed_relay_hw_off();
int ed_relay_get_state();
int ed_relay_get_hw_state();
int ed_relay_set_state(int state);
int ed_relay_set_hw_state(int state);

void ed_relay_report();
void ed_relay_hw_report();

#endif // ED_RELAY_H