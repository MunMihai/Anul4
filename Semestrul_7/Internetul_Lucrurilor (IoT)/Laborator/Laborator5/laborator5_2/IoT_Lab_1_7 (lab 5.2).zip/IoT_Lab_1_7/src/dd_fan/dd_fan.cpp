#include "dd_fan.h"
#include "ed_relay/ed_relay.h"
#include "stdio.h"

int dd_fan_state = 0;

int dd_fan_get_state()
{
    return dd_fan_state;
}
int dd_fan_set_state(int state)
{
    if (state == DD_FAN_ON)
    {
        dd_fan_state = DD_FAN_ON;
    }
    else
    {
        dd_fan_state = DD_FAN_OFF;
    }
    return dd_fan_state;
}

int dd_fan_on()
{
    int out_state = dd_fan_set_state(DD_FAN_ON);
    return out_state;
}
int dd_fan_off()
{
    int out_state = dd_fan_set_state(DD_FAN_OFF);
    return out_state;
}

void dd_fan_report()
{
    if(dd_fan_state == DD_FAN_ON){
        printf("Fan is ON\n");
    }else{
        printf("Fan is OFF\n");
    }
}

void dd_fan_setup()
{
    // Set up the fan
    dd_fan_off();
}

void dd_fan_loop()
{
    // Run the fan loop
    // get the fans signal state
    int fan_state = dd_fan_get_state();

    // here some diagnostics could be performed before setting the fan

    if(fan_state == DD_FAN_ON){
        // apply fan signal state to the relay
        ed_relay_on();
    }else{
        // apply fan signal state to the relay
        ed_relay_off();
    }
}