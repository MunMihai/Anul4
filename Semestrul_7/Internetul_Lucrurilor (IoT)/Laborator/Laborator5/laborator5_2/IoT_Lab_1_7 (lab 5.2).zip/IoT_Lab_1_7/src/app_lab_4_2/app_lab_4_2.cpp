#include "app_lab_4_2.h"

#include "srv_heartbeat/srv_heartbeat_task.h"
#include "srv_serial_stdio/srv_serial_stdio.h"
#include "dd_dc_motor/dd_dc_motor_task.h"

#include "Arduino_FreeRTOS.h"

#include "Arduino.h"


#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif

#ifndef APP_LAB_4_2_TASK_REC
#define APP_LAB_4_2_TASK_REC (500 / SYS_TICK)
#endif

#ifndef APP_LAB_4_2_TASK_OFFSET
#define APP_LAB_4_2_TASK_OFFSET (1000 / SYS_TICK)
#endif

int potentiometer_pin = A0;

void app_lab_4_2_task_freertos(void *pvParameters)
{

    printf("App Lab 4.2 Task Initiated\n");

    vTaskDelay(APP_LAB_4_2_TASK_OFFSET);
    printf("App Lab 4.2 Task Started\n");

    while (1)
    {
        printf("App Lab 4.2 Task Run\n");

        int potentiometer_value = analogRead(potentiometer_pin);

        int motor_power = map(potentiometer_value, 0, 1023, -100, 100);
        printf("Potentiometer Value: %d\n", potentiometer_value);

        dd_dc_motor_set_power(motor_power);
        printf("Motor Power: %d\n", motor_power);

        vTaskDelay(APP_LAB_4_2_TASK_REC);
    }
}

void app_lab_4_2_setup(){
    // Set up the serial service
    srv_serial_setup();
    printf("App Lab 4.2 Setup\n");
    // Start up the heartbeat service
    xTaskCreate(srv_heartbeat_task_freertos, "Heartbeat", 2024, NULL, 1, NULL);
    // Start up the motor driver
    xTaskCreate(dd_dc_motor_task_freertos, "DC Motor", 2024, NULL, 1, NULL);
    // Start up the app lab 4.2 task
    xTaskCreate(app_lab_4_2_task_freertos, "App Lab 4.2", 2024, NULL, 1, NULL);

    // Start the FreeRTOS scheduler
    vTaskStartScheduler();
}

void app_lab_4_2_loop(){
    // This is a freeRTOS task, so it will run on its own.
    // We don't need to do anything here.
}
