#ifndef APP_LAB_2_1_H
#define APP_LAB_2_1_H


// Include any necessary libraries here

// Declare any global variables or constants here

// Declare function prototypes here

void app_lab_2_1_setup();
void app_lab_2_1_loop();

#endif // APP_LAB_2_1_H
