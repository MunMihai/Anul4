#ifndef ED_RELAY_TASK_H
#define ED_RELAY_TASK_H

// Include standard libraries
#include "Arduino_FreeRTOS.h"
// Include the project libraries
#include "ed_relay.h"

// Define any constants
#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif
#ifndef ED_RELAY_TASK_REC
#define ED_RELAY_TASK_REC (100/SYS_TICK)
#endif
#ifndef ED_RELAY_TASK_OFFSET
#define ED_RELAY_TASK_OFFSET (100/SYS_TICK)
#endif

// Declare any global variables

// Declare any function prototypes

void ed_relay_task_freertos(void *pvParameters);

#endif // ED_RELAY_TASK_H
