#ifndef DD_DC_MOTOR_H
#define DD_DC_MOTOR_H

// Include standard libraries

// Include the project libraries

// Define any constants

// Declare any global variables

// Declare any function prototypes

void dd_dc_motor_setup();
void dd_dc_motor_loop();
int dd_dc_motor_get_power();
int dd_dc_motor_set_power(int power);

#endif // DD_DC_MOTOR_H