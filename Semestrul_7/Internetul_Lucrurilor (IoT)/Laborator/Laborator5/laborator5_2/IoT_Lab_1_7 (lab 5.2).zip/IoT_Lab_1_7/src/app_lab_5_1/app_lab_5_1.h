#ifndef APP_LAB_5_1_H_
#define APP_LAB_5_1_H_


// Include standard libraries

// Include the project libraries

// Define any constants

// Declare any global variables

// Declare any function prototypes

void app_lab_5_1_setup();
void app_lab_5_1_loop();

#endif