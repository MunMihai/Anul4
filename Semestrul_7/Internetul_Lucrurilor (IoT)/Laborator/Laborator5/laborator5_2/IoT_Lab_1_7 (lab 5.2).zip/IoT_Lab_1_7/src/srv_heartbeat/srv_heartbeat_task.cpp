#include "srv_heartbeat.h"
#include "srv_heartbeat_task.h"
#include "Arduino_FreeRTOS.h"


//----------------------------------------------------------------
// FreeRTOS task adaptation of the reccuring heartbeat task
void srv_heartbeat_task_freertos(void *pvParameters)
{
    // Initialize the heartbeat component
    srv_heartbeat_setup();
    vTaskDelay(SRV_HEARTBEAT_TASK_OFFSET);

    while (1)
    {
        // Enter critical section
        taskENTER_CRITICAL();
        // As we are using printf inside the function
        // we need to protect the critical section

        // Run the heartbeat recurring loop
        srv_heartbeat_loop();

        // Exit critical section
        taskEXIT_CRITICAL();

        // Delay for the heartbeat task recurrence
        vTaskDelay(SRV_HEARTBEAT_TASK_REC);
    }
}
