#include "app_lab_3_2.h"
#include "srv_heartbeat/srv_heartbeat_task.h"
#include "srv_serial_stdio/srv_serial_stdio.h"
#include "ed_dht/ed_dht_task.h"
#include "Arduino_FreeRTOS.h"

#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif
#ifndef APP_LAB_3_2_TASK_REC
#define APP_LAB_3_2_TASK_REC (500 / SYS_TICK)
#endif
#ifndef APP_LAB_3_2_TASK_OFFSET
#define APP_LAB_3_2_TASK_OFFSET (1000 / SYS_TICK)
#endif

void app_lab_3_2_task_freertos(void *pvParameters)
{
    printf("App Lab 3.2 Task Initiated\n");

    vTaskDelay(APP_LAB_3_2_TASK_OFFSET);
    printf("App Lab 3.2 Task Started\n");

    while (1)
    {
        printf("App Lab 3.2 Task Run\n");

        // Print report of sensor conditioning
        ed_dht_report();
        // OR

        // Generate data for serial Plotter
        // dd_sns_angle_plot();

        vTaskDelay(APP_LAB_3_2_TASK_REC);
    }
}

void app_lab_3_2_setup()
{
    // Set up the serial service
    srv_serial_setup();
    printf("App Lab 3.2 Setup\n");
    // Start up the heartbeat service
    xTaskCreate(srv_heartbeat_task_freertos, "Heartbeat", 2024, NULL, 1, NULL);
    // Start up the temperature  sensor driver
    xTaskCreate(ed_dht_task_freertos, "TemperatureSensor", 2024, NULL, 1, NULL);
    // start app_lab_3_2_task_freertos
    xTaskCreate(app_lab_3_2_task_freertos, "AppLab3.2", 2024, NULL, 1, NULL);
    

    // Start the FreeRTOS scheduler
    vTaskStartScheduler();
}

void app_lab_3_2_loop()
{
    // Idle task in main loop
}