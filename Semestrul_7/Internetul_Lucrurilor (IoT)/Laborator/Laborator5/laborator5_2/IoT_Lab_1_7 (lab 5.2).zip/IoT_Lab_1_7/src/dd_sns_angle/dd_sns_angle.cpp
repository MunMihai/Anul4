#include "dd_sns_angle.h"
#include "Arduino.h"
#include "srv_sig_cond/srv_sig_cond.h"

#define DD_SNS_ANGLE_PIN A0

#define DD_SNS_ANGLE_RAW_MAX 1023
#define DD_SNS_ANGLE_RAW_MIN 0
#define DD_SNS_ANGLE_mVOLT_MAX 5000 // 5V
#define DD_SNS_ANGLE_mVOLT_MIN 0
#define DD_SNS_ANGLE_mVOLT_OFFSET 0

#define DD_SNS_ANGLE_MAX 180
#define DD_SNS_ANGLE_MIN 0 
#define DD_SNS_ANGLE_OFFSET 0 

#define DD_SNS_ANGLE_mVOLT_SAT_MAX 4000 // 4V
#define DD_SNS_ANGLE_mVOLT_SAT_MIN 1000 // 1V

void dd_sns_angle_setup(){
    // Set up the angle sensor
    pinMode(DD_SNS_ANGLE_PIN, INPUT);
}   

int dd_sns_raw_value = 0;
int dd_sns_mVolt_value = 0;
int dd_sns_mVolt_sat_value = 0;
int dd_sns_mVolt_median_value = 0;
int dd_sns_mVolt_wavg_value = 0;
int dd_sns_angle_phy = 0;

int dd_sns_angle_get_raw_value(){
    return dd_sns_raw_value;
}
int dd_sns_angle_get_mVolt_value(){
    return dd_sns_mVolt_value;
}
int dd_sns_angle_get_mVolt_sat_value(){
    return dd_sns_mVolt_sat_value;
}
int dd_sns_angle_get_mVolt_median_value(){
    return dd_sns_mVolt_median_value;
}
int dd_sns_angle_get_mVolt_wavg_value(){
    return dd_sns_mVolt_wavg_value;
}
int dd_sns_angle_get_phy_value(){
    return dd_sns_angle_phy;
}

#define DD_SNS_ANGLE_INPUT_BUFFER_SIZE 5
#define DD_SNS_ANGLE_WAVG_BUFFER_SIZE 4

int dd_sns_angle_median_buffer[DD_SNS_ANGLE_INPUT_BUFFER_SIZE];
int dd_sns_angle_median_buffer_copy[DD_SNS_ANGLE_INPUT_BUFFER_SIZE];

int dd_sns_angle_wavg_buffer[DD_SNS_ANGLE_WAVG_BUFFER_SIZE];
int dd_sns_angle_wavg_buffer_weights[DD_SNS_ANGLE_WAVG_BUFFER_SIZE]
                                = {50, 25, 15, 10};

void dd_sns_angle_loop(){

    // 1. collect raw value from the sensor
    dd_sns_raw_value = analogRead(DD_SNS_ANGLE_PIN);
    // print the raw value for debug purposes
    // printf("Angle Sensor Raw Value: %d\n", dd_sns_raw_value);

    // 2. Convert raw value to millivolts
    dd_sns_mVolt_value = map(
        dd_sns_raw_value,
        DD_SNS_ANGLE_RAW_MIN,
        DD_SNS_ANGLE_RAW_MAX,
        DD_SNS_ANGLE_mVOLT_MIN,
        DD_SNS_ANGLE_mVOLT_MAX
    );
    // Add the measurement  
    dd_sns_mVolt_value += DD_SNS_ANGLE_mVOLT_OFFSET;
    // print the mVolt value for debug purposes
    // printf("Angle Sensor mVolt Value: %d\n", dd_sns_mVolt_value);

    // 3. saturate signal to a range
    if(dd_sns_mVolt_value > DD_SNS_ANGLE_mVOLT_SAT_MAX){
        dd_sns_mVolt_sat_value = DD_SNS_ANGLE_mVOLT_SAT_MAX;
    }else if(dd_sns_mVolt_value < DD_SNS_ANGLE_mVOLT_SAT_MIN){
        dd_sns_mVolt_sat_value = DD_SNS_ANGLE_mVOLT_SAT_MIN;
    }else{ 
        dd_sns_mVolt_sat_value = dd_sns_mVolt_value;
    }
    // print the saturated mVolt value for debug purposes
    // printf("Angle Sensor mVolt Saturated Value: %d\n", dd_sns_mVolt_sat_value);

    // 4. salt and piper filter
    // 4.1 buffer the signal
    srv_sig_cond_fifo_push_int(dd_sns_mVolt_sat_value, dd_sns_angle_median_buffer, DD_SNS_ANGLE_INPUT_BUFFER_SIZE);
    // 4.2 copy the buffer
    srv_sig_cond_buff_copy_int(dd_sns_angle_median_buffer, dd_sns_angle_median_buffer_copy, DD_SNS_ANGLE_INPUT_BUFFER_SIZE);
    // 4.3 sort the copied buffer
    srv_sig_cond_buff_sort_int(dd_sns_angle_median_buffer_copy, DD_SNS_ANGLE_INPUT_BUFFER_SIZE);
    // 4.4 get the median value
    dd_sns_mVolt_median_value = dd_sns_angle_median_buffer_copy[DD_SNS_ANGLE_INPUT_BUFFER_SIZE/2];
    // print the median value for debug purposes
    // printf("Angle Sensor mVolt Median Value: %d\n", dd_sns_mVolt_median_value);

    //5. Weighted average filter (LPF)
    // 5.1 buffer the signal
    srv_sig_cond_fifo_push_int(dd_sns_mVolt_median_value, dd_sns_angle_wavg_buffer, DD_SNS_ANGLE_WAVG_BUFFER_SIZE);
    // 5.2 Extract weighted average
    dd_sns_mVolt_wavg_value = srv_sig_cond_buff_wavg_int(dd_sns_angle_wavg_buffer, dd_sns_angle_wavg_buffer_weights, DD_SNS_ANGLE_WAVG_BUFFER_SIZE);
    // print the weighted average value for debug purposes
    // printf("Angle Sensor mVolt Weighted Average Value: %d\n", dd_sns_mVolt_wavg_value);

    //6. convert voltage to angle physical value
    // 6.1 map the voltage to angle
    dd_sns_angle_phy = map(
        dd_sns_mVolt_wavg_value,
        DD_SNS_ANGLE_mVOLT_MIN,
        DD_SNS_ANGLE_mVOLT_MAX,
        DD_SNS_ANGLE_MIN,
        DD_SNS_ANGLE_MAX
    );
    // 6.2 add angle offset
    dd_sns_angle_phy += DD_SNS_ANGLE_OFFSET;
    // print the angle value for debug purposes
    // printf("Angle Sensor Angle Value: %d\n", dd_sns_angle_phy);

}

void dd_sns_angle_report(){
    int raw_value = dd_sns_angle_get_raw_value();
    int mVolt_value = dd_sns_angle_get_mVolt_value();
    int mVolt_sat_value = dd_sns_angle_get_mVolt_sat_value();
    int mVolt_median_value = dd_sns_angle_get_mVolt_median_value();
    int mVolt_wavg_value = dd_sns_angle_get_mVolt_wavg_value();
    int angle_phy = dd_sns_angle_get_phy_value();

    printf("Angle Sensor: Raw = %d | mVolt = %d | mVolt Sat = %d | mVolt Median = %d | mVolt Wavg = %d | Phy = %d\n",
        raw_value, mVolt_value, mVolt_sat_value, mVolt_median_value, mVolt_wavg_value, angle_phy);

}

// Plot the angle sensor data
// Use the serial plotter in the Arduino IDE
// https://docs.arduino.cc/software/ide-v2/tutorials/ide-v2-serial-plotter/
void dd_sns_angle_plot(){
    
    int raw_value = dd_sns_angle_get_raw_value();
    int mVolt_value = dd_sns_angle_get_mVolt_value();
    int mVolt_sat_value = dd_sns_angle_get_mVolt_sat_value();
    int mVolt_median_value = dd_sns_angle_get_mVolt_median_value();
    int mVolt_wavg_value = dd_sns_angle_get_mVolt_wavg_value();
    int angle_phy = dd_sns_angle_get_phy_value();

    printf(" raw_value: %d , mVolt_value: %d , mVolt_sat_value: %d , mVolt_median_value: %d , mVolt_wavg_value: %d , angle_phy: %d \r\n",
        raw_value, mVolt_value, mVolt_sat_value, mVolt_median_value, mVolt_wavg_value, angle_phy);

}