#include "dd_sns_angle_task.h"
#include "Arduino_FreeRTOS.h"


// FreeRTOS task adaptation of the reccuring angle sensor task
void dd_sns_angle_task_freertos(void *pvParameters)
{
    // Initialize the angle sensor component
    dd_sns_angle_setup();
    vTaskDelay(DD_SNS_ANGLE_TASK_OFFSET);

    while (1)
    {

        // Run the angle sensor recurring loop
        dd_sns_angle_loop();


        // Delay for the angle sensor task recurrence
        vTaskDelay(DD_SNS_ANGLE_TASK_REC);
    }
}


