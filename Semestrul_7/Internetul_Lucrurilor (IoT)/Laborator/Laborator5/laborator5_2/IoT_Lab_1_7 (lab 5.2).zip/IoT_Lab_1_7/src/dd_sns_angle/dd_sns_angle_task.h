#ifndef DD_SNS_ANGLE_TASK_H
#define DD_SNS_ANGLE_TASK_H


// Include standard libraries

// Include the project libraries
#include "dd_sns_angle.h"


// Define any constants
#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif
#ifndef DD_SNS_ANGLE_TASK_REC
#define DD_SNS_ANGLE_TASK_REC (10/SYS_TICK)
#endif
#ifndef DD_SNS_ANGLE_TASK_OFFSET
#define DD_SNS_ANGLE_TASK_OFFSET (100/SYS_TICK)
#endif

// Declare any global variables

// Declare any function prototypes

void dd_sns_angle_task_freertos(void *pvParameters);

#endif // DD_SNS_ANGLE_TASK_H