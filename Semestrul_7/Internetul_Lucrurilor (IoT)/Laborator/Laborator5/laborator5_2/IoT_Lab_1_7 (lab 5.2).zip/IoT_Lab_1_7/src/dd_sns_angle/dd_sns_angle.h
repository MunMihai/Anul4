#ifndef DD_SNS_ANGLE_H
#define DD_SNS_ANGLE_H


// Include standard libraries


// Include the project libraries


// Define any constants


// Declare any global variables


// Declare any function prototypes
void dd_sns_angle_setup();
void dd_sns_angle_loop();
int dd_sns_angle_get_raw_value();
int dd_sns_angle_get_mVolt_value();
int dd_sns_angle_get_mVolt_sat_value();
int dd_sns_angle_get_mVolt_median_value();
int dd_sns_angle_get_mVolt_wavg_value();
int dd_sns_angle_get_phy_value();
void dd_sns_angle_report();
void dd_sns_angle_plot();

#endif // DD_SNS_ANGLE_H