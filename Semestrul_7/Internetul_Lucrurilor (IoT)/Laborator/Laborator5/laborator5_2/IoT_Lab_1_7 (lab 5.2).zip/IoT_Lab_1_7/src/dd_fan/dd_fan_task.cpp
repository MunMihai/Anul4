#include "dd_fan_task.h"

// FreeRTOS task adaptation of the reccuring fan task
void dd_fan_task_freertos(void *pvParameters)
{
    // Initialize the fan component
    dd_fan_setup();
    vTaskDelay(DD_FAN_TASK_OFFSET);

    while (1)
    {

        // Run the fan recurring loop
        dd_fan_loop();

        // Delay for the fan task recurrence
        vTaskDelay(DD_FAN_TASK_REC);
    }
}