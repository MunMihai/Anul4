#ifndef SRV_HEARTBEAT_H
#define SRV_HEARTBEAT_H

void srv_heartbeat_setup();
void srv_heartbeat_loop();

#endif // SRV_HEARTBEAT_H