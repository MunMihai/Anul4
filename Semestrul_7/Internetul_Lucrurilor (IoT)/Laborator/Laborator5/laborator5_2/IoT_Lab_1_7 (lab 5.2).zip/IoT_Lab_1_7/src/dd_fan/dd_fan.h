#ifndef DD_FAN_H
#define DD_FAN_H

// Include standard libraries

// Include the project libraries

// Define any constants
#define DD_FAN_ON 1
#define DD_FAN_OFF 0

// Declare any global variables

// Declare any function prototypes

void dd_fan_setup();

void dd_fan_loop();

int dd_fan_get_state();
int dd_fan_set_state(int state);
int dd_fan_on();
int dd_fan_off();
void dd_fan_report();


#endif // DD_FAN_H
