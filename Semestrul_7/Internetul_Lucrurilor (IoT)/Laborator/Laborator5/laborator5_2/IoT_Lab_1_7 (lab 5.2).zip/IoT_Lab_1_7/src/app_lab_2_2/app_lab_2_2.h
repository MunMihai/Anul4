#ifndef APP_LAB_2_2_H
#define APP_LAB_2_2_H

// Include necessary libraries

// Define any constants or macros

// Declare any global variables or extern variables

// Declare any function prototypes
void app_lab_2_2_setup();
void app_lab_2_2_loop();

#endif // APP_LAB_2_2_H

