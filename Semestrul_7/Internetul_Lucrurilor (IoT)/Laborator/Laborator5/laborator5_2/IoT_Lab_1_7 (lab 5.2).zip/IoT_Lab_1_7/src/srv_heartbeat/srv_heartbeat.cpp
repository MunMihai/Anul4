#include "srv_heartbeat.h"
#include "dd_led/dd_led.h"
#include <stdio.h>


void srv_heartbeat_setup()
{
    // Set the heartbeat pin as an output
    dd_led_setup();
}

void srv_heartbeat_loop()
{
    // Toggle the heartbeat pin;
    dd_led_toggle();
    // for debug scope only
    printf("Heartbeat\n");

}