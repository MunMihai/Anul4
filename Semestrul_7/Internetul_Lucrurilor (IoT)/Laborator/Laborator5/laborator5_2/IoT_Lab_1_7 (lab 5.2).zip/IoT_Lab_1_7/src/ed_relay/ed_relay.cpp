#include "ed_relay.h"
#include "Arduino.h"
#include "stdio.h"

int ed_relay_state = 0;

void ed_relay_setup()
{
    // Set up the relay
    pinMode(ED_RELAY_PIN, OUTPUT);
    ed_relay_off();
}


void ed_relay_loop()
{
    // Run the relay loop
    // get the relays signal state
    int relay_state = ed_relay_get_state();

    // here some diagnostics could be performed before setting the relay

    // apply internal signal state to the HW relay
    ed_relay_set_hw_state(relay_state);
}


int ed_relay_get_state()
{
    return ed_relay_state;
}   

int ed_relay_set_state(int relay_state)
{
    if (relay_state == ED_RELAY_ON)
    {
        ed_relay_state = ED_RELAY_ON;
    }
    else
    {
        ed_relay_state = ED_RELAY_OFF;
    }
    return ed_relay_state;
}

int ed_relay_get_hw_state()
{
    int relay_state = digitalRead(ED_RELAY_PIN);
    return relay_state;
}

int ed_relay_set_hw_state(int relay_state)
{
    if (relay_state == ED_RELAY_ON)
    {
        digitalWrite(ED_RELAY_PIN, HIGH);
    }
    else
    {
        digitalWrite(ED_RELAY_PIN, LOW);
    }
    ed_relay_state = relay_state;
    return ed_relay_state;
}

int ed_relay_on()
{
    int out_state = ed_relay_set_state(ED_RELAY_ON);
    return out_state;
}

int ed_relay_off()
{
    int out_state = ed_relay_set_state(ED_RELAY_OFF);
    return out_state;
}


int ed_relay_hw_on()
{
    int out_state = ed_relay_set_hw_state(ED_RELAY_ON);
    return out_state;
}

int ed_relay_hw_off(){
    int out_state = ed_relay_set_hw_state(ED_RELAY_OFF);
    return out_state;
}

void ed_relay_report()
{
    int relay_state = ed_relay_get_state();
    if (relay_state == ED_RELAY_ON)
    {
        printf("Relay is ON\n");
    }
    else
    {
        printf("Relay is OFF\n");
    }
}

void ed_relay_hw_report()
{
    int relay_state = ed_relay_get_hw_state();
    if (relay_state == 1)
    {
        printf("Relay HW is ON\n");
    }
    else
    {
        printf("Relay HW is OFF\n");
    }
}