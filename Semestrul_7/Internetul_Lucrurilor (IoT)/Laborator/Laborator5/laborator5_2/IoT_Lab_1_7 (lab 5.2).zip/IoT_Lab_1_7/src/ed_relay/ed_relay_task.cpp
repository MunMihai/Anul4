#include "ed_relay_task.h"
#include "ed_relay.h"

// FreeRTOS task adaptation of the reccuring relay task
void ed_relay_task_freertos(void *pvParameters)
{
    // Initialize the relay component
    ed_relay_setup();
    vTaskDelay(ED_RELAY_TASK_OFFSET);

    while (1)
    {

        // Run the relay recurring loop
        ed_relay_loop();

        // Delay for the relay task recurrence
        vTaskDelay(ED_RELAY_TASK_REC);
    }
}