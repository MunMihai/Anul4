#ifndef LIB_UTILS_H
#define LIB_UTILS_H


// Include standard libraries


// Include the project libraries


// Define any constants


// Declare any global variables


// Declare any function prototypes


void my_delay(long delay_ms);

#endif // LIB_UTILS_H