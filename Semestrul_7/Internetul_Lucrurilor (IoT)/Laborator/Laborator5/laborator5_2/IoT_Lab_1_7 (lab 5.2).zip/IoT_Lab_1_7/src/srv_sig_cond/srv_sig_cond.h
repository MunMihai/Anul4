#ifndef SRV_SIG_COND_H_
#define SRV_SIG_COND_H_

#include <stdint.h>

int srv_sig_cond_fifo_push_float(float data, float *buff, int buff_size);
int srv_sig_cond_fifo_push_int(int data, int *buff, int buff_size);

int srv_sig_cond_buff_copy_float(float *buff_src, float *buff_dst, int buff_size);
int srv_sig_cond_buff_copy_int(int *buff_src, int *buff_dst, int buff_size);

int srv_sig_cond_buff_sort_float(float *buff, int buff_size);
int srv_sig_cond_buff_sort_int(int *buff, int buff_size);

float srv_sig_cond_buff_wavg_float(float *buff_data, float *buff_weight, int buff_size);
int srv_sig_cond_buff_wavg_int(int *buff_data, int *buff_weight, int buff_size);
long srv_sig_cond_buff_wavg_long(long *buff_data, long *buff_weight, long buff_size);

int srv_sig_cond_print_buff_float(float *buff, int buff_size);
int srv_sig_cond_print_buff_int(int *buff, int buff_size);

#endif