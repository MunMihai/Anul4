#ifndef APP_LAB_4_1_H
#define APP_LAB_4_1_H

// Include standard libraries

// Include the project libraries

// Define any constants

// Declare any global variables

// Declare any function prototypes

void app_lab_4_1_setup();
void app_lab_4_1_loop();

#endif // APP_LAB_4_1_H