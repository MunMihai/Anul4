#ifndef APP_LAB_5_2_H_
#define APP_LAB_5_2_H_

// Include standard libraries

// Include the project libraries

// Define any constants

// Declare any global variables

// Declare any function prototypes

void app_lab_5_2_setup();
void app_lab_5_2_loop();

#endif