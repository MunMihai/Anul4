#ifndef APP_LAB_3_2_H
#define APP_LAB_3_2_H


// Include standard libraries


// Include the project libraries


// Define any constants


// Declare any global variables


// Declare any function prototypes

void app_lab_3_2_setup();

void app_lab_3_2_loop();


#endif // APP_LAB_3_2_H