#include "app_lab_3_1.h"
#include "Arduino_FreeRTOS.h"
#include "srv_serial_stdio/srv_serial_stdio.h"
#include "srv_heartbeat/srv_heartbeat_task.h"
#include "dd_sns_angle/dd_sns_angle_task.h"


#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif
#ifndef APP_LAB_3_1_TASK_REC
#define APP_LAB_3_1_TASK_REC (500 / SYS_TICK)
#endif
#ifndef APP_LAB_3_1_TASK_OFFSET
#define APP_LAB_3_1_TASK_OFFSET (1000 / SYS_TICK)
#endif

void app_lab_3_1_task_freertos(void *pvParameters)
{

    printf("App Lab 3.1 Task Initiated\n");

    vTaskDelay(APP_LAB_3_1_TASK_OFFSET);
    printf("App Lab 3.1 Task Started\n");

    while (1)
    {
        // printf("App Lab 3.1 Task Run\n");

        // Print report of sensor conditioning
        dd_sns_angle_report();

        // OR

        // Generate data for serial Plotter
        // dd_sns_angle_plot();

        vTaskDelay(APP_LAB_3_1_TASK_REC);
    }
}

void app_lab_3_1_setup()
{
    // Set up the serial service
    srv_serial_setup();
    printf("App Lab 3.1 Setup\n");
    // Start up the heartbeat service
    xTaskCreate(srv_heartbeat_task_freertos, "Heartbeat", 2024, NULL, 1, NULL);
    // Start up the angle sensor driver
    xTaskCreate(dd_sns_angle_task_freertos, "AngleSensor", 2024, NULL, 1, NULL);
    // start app_lab_3_1_task_freertos
    xTaskCreate(app_lab_3_1_task_freertos, "AppLab3.1", 2024, NULL, 1, NULL);

    // Start the FreeRTOS scheduler
    vTaskStartScheduler();
}

// Idle task in main loop
void app_lab_3_1_loop()
{
    // do nothing
}