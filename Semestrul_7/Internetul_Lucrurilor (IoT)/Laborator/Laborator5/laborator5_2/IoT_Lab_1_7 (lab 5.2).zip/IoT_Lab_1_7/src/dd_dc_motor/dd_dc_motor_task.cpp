#include "dd_dc_motor_task.h"
#include "stdio.h"

void dd_dc_motor_task_freertos(void *pvParameters)
{
    printf("DC Motor Task Initiated\n");

    vTaskDelay(DD_DC_MOTOR_TASK_OFFSET);
    printf("DC Motor Task Started\n");

    while (1)
    {
        // printf("DC Motor Task Run\n");

        dd_dc_motor_loop();

        vTaskDelay(DD_DC_MOTOR_TASK_REC);
    }
}