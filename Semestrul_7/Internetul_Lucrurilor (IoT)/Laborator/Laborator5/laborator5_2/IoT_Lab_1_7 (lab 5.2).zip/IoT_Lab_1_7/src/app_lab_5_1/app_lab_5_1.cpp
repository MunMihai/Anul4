#include "app_lab_5_1.h"

#include "srv_heartbeat/srv_heartbeat_task.h"
#include "srv_serial_stdio/srv_serial_stdio.h"
#include "dd_dc_motor/dd_dc_motor_task.h"
#include "dd_sns_angle/dd_sns_angle_task.h"

#include "Arduino_FreeRTOS.h"

#include "Arduino.h"


#ifndef SYS_TICK
#define SYS_TICK portTICK_PERIOD_MS
#endif

#ifndef APP_LAB_5_1_TASK_REC
#define APP_LAB_5_1_TASK_REC (10 / SYS_TICK)
#endif

#ifndef APP_LAB_5_1_TASK_OFFSET
#define APP_LAB_5_1_TASK_OFFSET (1000 / SYS_TICK)
#endif

int CTRL_ON_OFF_K = 35;
int CTRL_ON_OFF_DELTA = 5;
int ctrl_on_off_desired_value = 90;
int ctrl_on_off_current_value = 0;
int ctrl_on_off_error = 0;
int ctrl_on_off_out = 0;

void app_lab_5_1_task_freertos(void *pvParameters)
{

    printf("App Lab 5.1 Task Initiated\n");

    vTaskDelay(APP_LAB_5_1_TASK_OFFSET);
    printf("App Lab 5.1 Task Started\n");

    while (1)
    {
        // printf("App Lab 5.1 Task Run\n");

        ctrl_on_off_current_value = dd_sns_angle_get_phy_value();
        // print current positin
        // printf("Current Value: %d\n", current_value);

        if(Serial.available() > 0){
            ctrl_on_off_desired_value = Serial.parseInt();
            // printf("Desired Value Updated: %d\n", ctrl_on_off_desired_value);
        }

        // print desired value
        // printf("Desired Value: %d\n", ctrl_on_off_desired_value);

        int desired_value_low = ctrl_on_off_desired_value - CTRL_ON_OFF_DELTA;
        // print desired value left
        // printf("Desired Value High: %d\n", desired_value_low);

        int desired_value_high = ctrl_on_off_desired_value + CTRL_ON_OFF_DELTA;
        // print desired value right
        // printf("Desired Value Low: %d\n", desired_value_high);


        ctrl_on_off_error = ctrl_on_off_desired_value - ctrl_on_off_current_value;
        // print ctrl_on_off_error
        // printf("Error: %d\n", ctrl_on_off_error);

        if (desired_value_high < ctrl_on_off_current_value)
        {
            ctrl_on_off_out = -1;
        }
        else if (desired_value_low > ctrl_on_off_current_value)
        {
            ctrl_on_off_out = 1;
        }
        else
        {
        //  ctrl_on_off_out = ctrl_on_off_out; // for temperature control
           ctrl_on_off_out = 0; //  for angle control
        }

        // print control output
        // printf("Control Output: %d\n", ctrl_on_off_out);
        int ctrl_out_power = CTRL_ON_OFF_K * ctrl_on_off_out;
        // print motor power
        // printf("Motor Power: %d\n", ctrl_out_power);

        dd_dc_motor_set_power(ctrl_out_power);

        // Arduino terminal Plotter
        printf("Vd:%d, Vl:%d, Vr:%d, Vc:%d, Err:%d Out:%d, Pwr:%d\n\r", 
                ctrl_on_off_desired_value, 
                desired_value_low, 
                desired_value_high, 
                ctrl_on_off_current_value, 
                ctrl_on_off_error, 
                ctrl_on_off_out, 
                ctrl_out_power);

        vTaskDelay(APP_LAB_5_1_TASK_REC);
    }
}

void app_lab_5_1_setup()
{

    // Set up the serial service
    srv_serial_setup();
    printf("App Lab 5.1 Setup\n");
    // Start up the heartbeat service
    xTaskCreate(srv_heartbeat_task_freertos, "Heartbeat", 1024, NULL, 1, NULL);
    // Start up the motor driver
    xTaskCreate(dd_dc_motor_task_freertos, "DC Motor", 1024, NULL, 1, NULL);
    // Start upt the angle sensor
    xTaskCreate(dd_sns_angle_task_freertos, "Angle Sensor", 2024, NULL, 1, NULL);
    // Start up the app lab 5.1 task
    xTaskCreate(app_lab_5_1_task_freertos, "App Lab 5.1", 2024, NULL, 1, NULL);  

    // start scheduler
    vTaskStartScheduler();
}


void app_lab_5_1_loop()
{

}