#ifndef ED_DHT_H
#define ED_DHT_H


// Include standard libraries

// Include the project libraries

// Define any constants

// Declare any global variables

// Declare any function prototypes


float ed_dht_get_humidity();
int ed_dht_get_humidity_error();

float ed_dht_get_temperature();
int ed_dht_get_temperature_error();

float ed_dht_get_temperature_f() ;
int ed_dht_get_temperature_f_error() ;

int ed_dht_get_error() ;

void ed_dht_report();


void ed_dht_setup();
void ed_dht_loop();

#endif // ED_DHT_H