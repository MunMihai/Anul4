#include "dd_dc_motor.h"
#include "ed_l298/ed_l298.h"
#include "Arduino.h"

int dd_dc_motor_power = 0;

int dd_dc_motor_get_power()
{
    return dd_dc_motor_power;
}
int dd_dc_motor_set_power(int power)
{
    if (power > 100)
    {
        power = 100;
    }
    if (power < -100)
    {
        power = -100;
    }
    dd_dc_motor_power = power;
    return dd_dc_motor_power;
}

void dd_dc_motor_setup()
{
    // Set up the L298
    ed_l298_setup();
}

void dd_dc_motor_loop()
{
    // Run the motor loop
    // get the motors power state
    int motor_power = dd_dc_motor_get_power();
    motor_power = map(motor_power, -100, 100, -255, 255);

    // here some diagnostics could be performed before setting the motor
    if (motor_power > 0)
    {
        // apply motor power state to the motor
        ed_l298_set_hw_power(ED_L298_CHANNEL_1, motor_power);
        ed_l298_set_hw_power(ED_L298_CHANNEL_2, 0);
        ed_l298_ENA_on();
    }
    else if (motor_power < 0)
    {
        // apply motor power state to the motor
        ed_l298_set_hw_power(ED_L298_CHANNEL_1, 0);
        ed_l298_set_hw_power(ED_L298_CHANNEL_2, -motor_power);
        ed_l298_ENA_on();
    }
    else
    {
        // apply motor power state to the motor
        ed_l298_set_hw_power(ED_L298_CHANNEL_1, 0);
        ed_l298_set_hw_power(ED_L298_CHANNEL_2, 0);
        ed_l298_ENA_off();
    }

}


